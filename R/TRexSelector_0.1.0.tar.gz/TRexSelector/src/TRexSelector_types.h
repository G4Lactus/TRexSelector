// ========================================================================================
// TRexSelector_types.h
// ========================================================================================
#ifndef TREXSELECTOR_TYPES_H
#define TREXSELECTOR_TYPES_H
// ========================================================================================
/**
 * @file TRexSelector_types.h
 * @brief Forward declarations and type definitions for TRexSelector.
 * @details This header file contains forward declarations and type definitions for the
 *          various classes and structures used in the T-Rex Selector package. It is
 *          included by RcppExports.cpp to ensure that all custom C++ types used in
 *          XPtr<...> are properly declared for Rcpp.
 */
// ========================================================================================

// ml_methods includes
#include <ml_methods/standardization/z_score_scaler.hpp>
#include <ml_methods/standardization/lp_norm_scaler.hpp>
#include <ml_methods/model_selection/ridge_cv.hpp>
#include <ml_methods/model_selection/ridge_gcv.hpp>

// tsolvers includes
#include <tsolvers/tsolver_base.hpp>
#include <tsolvers/linear_model/lars_based/tlars_solver.hpp>
#include <tsolvers/linear_model/omp_based/tomp_solver.hpp>

// utils includes
#include <utils/memmap/memory_mapped_matrix.hpp>


// Bring the types into the global namespace or use aliases so RcppExports.cpp finds
// them without qualification.
using trex::ml_methods::standardization::ZScoreScaler;
using trex::ml_methods::standardization::LpNormScaler;
using trex::ml_methods::model_selection::ridge_cv;
using trex::ml_methods::model_selection::ridge_gcv;

using trex::tsolvers::TSolver_Base;
using trex::tsolvers::linear_model::lars_based::TLARS_Solver;
using trex::tsolvers::linear_model::omp_based::TOMP_Solver;

using trex::utils::memmap::MemoryMappedMatrix;
using trex::utils::memmap::AccessMode;

// ========================================================================================
#endif /* End of TREXSELECTOR_TYPES_H */
// ========================================================================================
