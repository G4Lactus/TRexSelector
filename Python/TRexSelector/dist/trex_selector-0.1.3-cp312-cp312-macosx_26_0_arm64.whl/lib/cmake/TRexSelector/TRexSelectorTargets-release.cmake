#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "TRexSelector::trex_utils" for configuration "Release"
set_property(TARGET TRexSelector::trex_utils APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(TRexSelector::trex_utils PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libtrex_utils.a"
  )

list(APPEND _cmake_import_check_targets TRexSelector::trex_utils )
list(APPEND _cmake_import_check_files_for_TRexSelector::trex_utils "${_IMPORT_PREFIX}/lib/libtrex_utils.a" )

# Import target "TRexSelector::trex_ml_methods" for configuration "Release"
set_property(TARGET TRexSelector::trex_ml_methods APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(TRexSelector::trex_ml_methods PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libtrex_ml_methods.a"
  )

list(APPEND _cmake_import_check_targets TRexSelector::trex_ml_methods )
list(APPEND _cmake_import_check_files_for_TRexSelector::trex_ml_methods "${_IMPORT_PREFIX}/lib/libtrex_ml_methods.a" )

# Import target "TRexSelector::trex_tsolvers" for configuration "Release"
set_property(TARGET TRexSelector::trex_tsolvers APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(TRexSelector::trex_tsolvers PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libtrex_tsolvers.a"
  )

list(APPEND _cmake_import_check_targets TRexSelector::trex_tsolvers )
list(APPEND _cmake_import_check_files_for_TRexSelector::trex_tsolvers "${_IMPORT_PREFIX}/lib/libtrex_tsolvers.a" )

# Import target "TRexSelector::trex_selector_methods" for configuration "Release"
set_property(TARGET TRexSelector::trex_selector_methods APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(TRexSelector::trex_selector_methods PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libtrex_selector_methods.a"
  )

list(APPEND _cmake_import_check_targets TRexSelector::trex_selector_methods )
list(APPEND _cmake_import_check_files_for_TRexSelector::trex_selector_methods "${_IMPORT_PREFIX}/lib/libtrex_selector_methods.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
