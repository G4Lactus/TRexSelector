# cmake/TRexSelectorConfig.cmake.in
# This is the TEMPLATE source — do not edit the generated output in the build directory.

####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was TRexSelectorConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)

# ── Required dependencies (must match root CMakeLists.txt) ──────────────────
find_dependency(Eigen3    REQUIRED NO_MODULE)
find_dependency(OpenMP    REQUIRED)
find_dependency(cereal    REQUIRED)
find_dependency(Boost 1.80 REQUIRED COMPONENTS headers)

# BLAS/LAPACK: mirror the Accelerate → OpenBLAS fallback logic
if(APPLE)
    set(BLA_VENDOR Apple)
    find_dependency(BLAS)
    find_dependency(LAPACK)
    if(NOT BLAS_FOUND)
        set(BLA_VENDOR OpenBLAS)
        find_dependency(BLAS  REQUIRED)
        find_dependency(LAPACK REQUIRED)
    endif()
else()
    find_dependency(BLAS  REQUIRED)
    find_dependency(LAPACK REQUIRED)
endif()

# ── Pull in exported targets ────────────────────────────────────────────────
include("${CMAKE_CURRENT_LIST_DIR}/TRexSelectorTargets.cmake")

# Verify all requested components are present
check_required_components(TRexSelector)
