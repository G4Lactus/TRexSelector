// =====================================================================================
// utils_bindings.hpp - Pybind11 bindings for utility classes and functions
// =====================================================================================
#ifndef TREX_PYTHON_UTILS_BINDINGS_HPP
#define TREX_PYTHON_UTILS_BINDINGS_HPP
// =====================================================================================
/**
 * @file utils_bindings.hpp
 * @brief Pybind11 bindings for utility classes and functions.
 */
// =====================================================================================

// pybind11 includes
#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>

// utils includes
#include <utils/memmap/memory_mapped_matrix.hpp>

// =====================================================================================

namespace py = pybind11;

// =====================================================================================

/**
 * @brief Binds the utility structures such as memory-mapped matrices.
 *
 * @param m The Python module to bind against.
 */
inline void bind_utils_module(py::module& m) {
    using trex::utils::memmap::AccessMode;
    using trex::utils::memmap::MemoryMappedMatrix;

    py::enum_<AccessMode>(m, "AccessMode")
        .value("ReadOnly", AccessMode::ReadOnly)
        .value("ReadWrite", AccessMode::ReadWrite)
        .export_values();

    py::class_<MemoryMappedMatrix<double>>(m, "MemoryMappedMatrix")
        .def(py::init<const std::string&, std::size_t, std::size_t, AccessMode>(),
             py::arg("filename"), py::arg("rows"), py::arg("cols"),
             py::arg("mode") = AccessMode::ReadWrite)
        .def("rows", &MemoryMappedMatrix<double>::rows)
        .def("cols", &MemoryMappedMatrix<double>::cols)
        .def("size", &MemoryMappedMatrix<double>::size)
        // Expose zero-copy numpy array mapped to the memory
        .def("to_numpy", [](MemoryMappedMatrix<double>& mmap_mat) -> py::array_t<double> {
            auto map = mmap_mat.getMap();
            // Create a NumPy array sharing the buffer, with Fortran (column-major) strides
            return py::array_t<double>(
                {map.rows(), map.cols()},                         // shape
                {sizeof(double), map.rows() * sizeof(double)},  // strides (column-major)
                map.data(),                                                 // pointer to data
                py::cast(&mmap_mat)                                 // base object to tied lifecycle
            );
        }, "Returns a zero-copy NumPy array view of the memory-mapped matrix.");

    m.def("convert_to_memory_mapped", [](py::array_t<double> arr, const std::string& filename) {
        py::buffer_info buf = arr.request();
        if (buf.ndim != 2) {
            throw std::runtime_error("Only 2D arrays are supported for memory mapping conversion.");
        }
        std::size_t rows = buf.shape[0];
        std::size_t cols = buf.shape[1];
        
        // Ensure Fortran contiguous (column-major) layout for Eigen compatibility
        py::array_t<double, py::array::f_style | py::array::forcecast> f_arr(arr);
        py::buffer_info f_buf = f_arr.request();
        
        MemoryMappedMatrix<double> mmap(filename, rows, cols, AccessMode::ReadWrite);
        auto map = mmap.getMap();
        std::memcpy(map.data(), f_buf.ptr, rows * cols * sizeof(double));
    }, py::arg("array"), py::arg("filename"), "Converts a NumPy array to a memory-mapped binary file.");
}

// =====================================================================================
#endif /* End of TREX_PYTHON_UTILS_BINDINGS_HPP */
// =====================================================================================
