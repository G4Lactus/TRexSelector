## ----include = FALSE----------------------------------------------------------
# Store user's options()
old_options <- options()

library(knitr)
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.align = "center",
  fig.retina = 2,
  out.width = "85%",
  dpi = 96
)
options(width = 80)

## ----eval=FALSE---------------------------------------------------------------
# # Option 1: Install stable version from CRAN
# install.packages("TRexSelector")
# 
# # Option 2: Install developer version from GitHub
# install.packages("devtools")
# devtools::install_github("G4Lactus/TRexSelector")

## ----eval=FALSE---------------------------------------------------------------
# library(TRexSelector)
# help(package = "TRexSelector")
# ?TRexSelector
# ?trex_control
# ?compute_fdp
# ?compute_tpp
# # etc.

## ----eval=FALSE---------------------------------------------------------------
# citation("TRexSelector")

## -----------------------------------------------------------------------------
library(TRexSelector)

# Setup
n <- 75 # number of observations
p <- 150 # number of variables
num_act <- 3 # number of true active variables
beta <- c(rep(1, times = num_act), rep(0, times = p - num_act)) # coefficient vector
true_actives <- which(beta > 0) # indices of true active variables

# Generate Gaussian data
set.seed(123)
X <- matrix(stats::rnorm(n * p), nrow = n, ncol = p)
y <- X %*% beta + stats::rnorm(n)

## -----------------------------------------------------------------------------
# Seed
set.seed(1234)

# Variable selection via T-Rex
sel <- TRexSelector$new(X, y, tFDR = 0.05, verbose = FALSE)
sel$select()

paste0("True active variables: ", paste(as.character(true_actives), collapse = ", "))
paste0("Selected variables:    ", paste(as.character(sel$selected_indices), collapse = ", "))

## -----------------------------------------------------------------------------
# Note: computations use the C++ backend and complete in well under 5 minutes.

# Seed
set.seed(1234)

# Setup
n <- 100 # number of observations
p <- 150 # number of variables

# Parameters
num_act <- 10 # number of true active variables
beta <- rep(0, times = p) # coefficient vector (all zeros first)
beta[sample(seq(p), size = num_act, replace = FALSE)] <- 1 # active variables with non-zero coefficients
true_actives <- which(beta > 0) # indices of true active variables
tFDR_vec <- c(0.1, 0.15, 0.2, 0.25) # target FDR levels
MC <- 100 # number of Monte Carlo runs per stopping point

# Initialize results vectors
FDP_mat <- matrix(NA, nrow = MC, ncol = length(tFDR_vec))
TPP_mat <- matrix(NA, nrow = MC, ncol = length(tFDR_vec))

# Run simulations
for (t in seq_along(tFDR_vec)) {
  for (mc in seq(MC)) {

    # Generate Gaussian data
    X <- matrix(stats::rnorm(n * p), nrow = n, ncol = p)
    y <- X %*% beta + stats::rnorm(n)

    # Run T-Rex selector
    sel <- TRexSelector$new(X, y, tFDR = tFDR_vec[t], verbose = FALSE)
    sel$select()

    # Results
    FDP_mat[mc, t] <- compute_fdp(sel$selected_indices, true_actives)
    TPP_mat[mc, t] <- compute_tpp(sel$selected_indices, true_actives)
  }
}

# Compute estimates of FDR and TPR by averaging FDP and TPP over MC Monte Carlo runs
FDR <- colMeans(FDP_mat)
TPR <- colMeans(TPP_mat)

## ----FDR_and_TPR, echo=FALSE, fig.align='center', message=FALSE, fig.width=12, fig.height=5, out.width = "95%"----
# Plot results
library(ggplot2)
library(patchwork)
tFDR_vec_percent <- 100 * tFDR_vec
plot_data <- data.frame(tFDR_vec = tFDR_vec_percent,
                        FDR = 100 * FDR,
                        TPR = 100 * TPR)

# FDR vs. tFDR
FDR_vs_tFDR <-
  ggplot(plot_data, aes(x = tFDR_vec_percent, y = FDR)) +
  labs(x = "Target FDR", y = "FDR") +
  scale_x_continuous(breaks = tFDR_vec_percent,
                     minor_breaks = c(),
                     limits = c(tFDR_vec_percent[1], tFDR_vec_percent[length(tFDR_vec_percent)])) +
  scale_y_continuous(breaks = seq(0, 100, by = 10), minor_breaks = c(), limits = c(0, 100)) +
  geom_line(linewidth = 1.5, colour = "#336C68") +
  geom_abline(slope = 1, colour = "red", linetype = 2, linewidth = 1) +
  geom_point(size = 2.5, colour = "#336C68") +
  theme_bw(base_size = 16) +
  theme(panel.background = element_rect(fill = "white", color = "black", linewidth = 1)) +
  coord_fixed(
    ratio =  0.75 * (tFDR_vec_percent[length(tFDR_vec_percent)] - tFDR_vec_percent[1]) / (100 - 0)
  )

# TPR vs. tFDR
TPR_vs_tFDR <-
  ggplot(plot_data, aes(x = tFDR_vec_percent, y = TPR)) +
  labs(x = "Target FDR", y = "TPR") +
  scale_x_continuous(breaks = tFDR_vec_percent, minor_breaks = c(),
                     limits = c(tFDR_vec_percent[1], tFDR_vec_percent[length(tFDR_vec_percent)])) +
  scale_y_continuous(breaks = seq(0, 100, by = 10), minor_breaks = c(), limits = c(0, 100)) +
  geom_line(linewidth = 1.5, colour = "#336C68") +
  geom_point(size = 2.5, colour = "#336C68") +
  theme_bw(base_size = 16) +
  theme(panel.background = element_rect(fill = "white", color = "black", linewidth = 1)) +
  coord_fixed(
    ratio =  0.75 * (tFDR_vec_percent[length(tFDR_vec_percent)] - tFDR_vec_percent[1]) / (100 - 0)
  )
FDR_vs_tFDR + TPR_vs_tFDR

## ----T-Rex_framework, echo=FALSE, fig.cap="Figure 1: Simplified overview of the T-Rex framework.", out.width = '85%'----
knitr::include_graphics("./figures/T-Rex_framework.png")

## ----EnlargedPredictorMatrix, echo=FALSE, fig.cap="Figure 2: The enlarged predictor matrix (predictor matrix with dummies).", out.width = '65%'----
knitr::include_graphics("./figures/predictor_matrix_with_dummies.png")

## ----include = FALSE----------------------------------------------------------
# Reset user's options()
options(old_options)

